module.exports = {
	apiEndpoint : "/api/v1",
	database : "mysql://b5435e01f8940b:71eaa941@us-cdbr-iron-east-01.cleardb.net/heroku_4678f524ca4dd14?reconnect=true",
	port : process.env.PORT || 9000
};